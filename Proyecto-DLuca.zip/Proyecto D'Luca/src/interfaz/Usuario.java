/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

/**
 *
 * @author user
 */
public class Usuario {
    
    public Usuario() {
    }
    
    
    
    public int autenticar(String sUsuario, String sContraseña) throws SQLException{
        int resultado = -1;
        
        ConexionBD conec = new ConexionBD();
        Connection connectbd = conec.conexion();
        String comando = "SELECT * FROM usuario WHERE Nombre LIKE '%" + sUsuario + "%' AND Contraseña LIKE '%" + sContraseña + "%'";
        
        PreparedStatement pst = connectbd.prepareStatement(comando);
        ResultSet result = null;
        result = pst.executeQuery(comando);
        while(result.next()){
            resultado++;
        }
        
        return resultado;
    }
}
